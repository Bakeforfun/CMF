﻿// (c) Konstantin Brownstein 2016

namespace BaseEntities {
    public enum Side {
        Buy,
        Sell
    }
}