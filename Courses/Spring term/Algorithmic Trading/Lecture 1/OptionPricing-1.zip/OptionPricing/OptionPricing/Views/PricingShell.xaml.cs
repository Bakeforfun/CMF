﻿using System.Windows;

namespace OptionPricing.Views {
    /// <summary>
    ///     Interaction logic for PricingShell.xaml
    /// </summary>
    public partial class PricingShell : Window {
        public PricingShell() {
            InitializeComponent();
        }
    }
}