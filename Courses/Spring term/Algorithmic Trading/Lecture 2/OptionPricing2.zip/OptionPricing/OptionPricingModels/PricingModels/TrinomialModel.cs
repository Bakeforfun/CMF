﻿// (c) Konstantin Brownstein 2016, except implementation

namespace OptionPricingModels.PricingModels {
    internal class TrinomialModel : IOptionsPricingModel {
        public void Compute(OptionPosition option) {
            // TODO : Implement
            // option.OptionPrice = 
            // option.Delta = 
            // option.Gamma = 
            // option.Vega = 
            // option.Theta = 
            // option.Rho = 
        }
    }
}