﻿namespace NaiveOptionMVVM.Services {
    public enum OptionType {
        Call,
        Put
    }
}