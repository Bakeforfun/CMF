﻿using System;

namespace HelloWorld {
    internal class Program {
        private static void Main(string[] args) {
            Console.WriteLine("Hello, world!");
        }
    }
}