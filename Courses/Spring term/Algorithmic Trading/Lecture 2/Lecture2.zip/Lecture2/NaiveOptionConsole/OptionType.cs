﻿namespace NaiveOptionConsole {
    public enum OptionType {
        Call,
        Put
    }
}