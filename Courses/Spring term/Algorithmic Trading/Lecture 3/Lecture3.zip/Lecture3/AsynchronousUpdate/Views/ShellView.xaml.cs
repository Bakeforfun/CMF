﻿using System.Windows;

namespace AsynchronousUpdate.Views {
    /// <summary>
    ///     Interaction logic for ShellView.xaml
    /// </summary>
    public partial class ShellView : Window {
        public ShellView() {
            InitializeComponent();
        }
    }
}